################################################################################
#                                                                              #
#  FØRSTE DAG PÅ SKOLEN                                                        #
#  Visual novel · L1 del curso Velkommen til Norge!                            #
#                                                                              #
#  Autora: Noelia Oviedo Marín                                                 #
#  Curso: Máster en Letras Digitales 2025-2026                                 #
#  Licencia: CC BY-NC-SA 4.0                                                   #
#                                                                              #
#  Duración estimada: 12 minutos                                               #
#  Estructura: escena lineal con 5 decisiones                                  #
#  Las decisiones no ramifican la historia, pero sí dan feedback distinto      #
#  para que el alumno entienda cuándo cada saludo/expresión queda natural.     #
#                                                                              #
################################################################################


# ============================================================================
# CONFIGURACIÓN
# ============================================================================

define config.name = "Første dag på skolen"
define config.version = "1.0"
define config.has_sound = False
define config.has_music = False
define config.window_title = "Første dag på skolen · L1"


# ============================================================================
# PERSONAJES
# ============================================================================

define sara = Character(
    "Sara",
    color="#c97b3c",
    what_prefix="«", what_suffix="»"
)

define jonas = Character(
    "Jonas",
    color="#2c5f8d",
    what_prefix="«", what_suffix="»"
)

define mc = Character(
    "Tú",
    color="#1a3a5c",
    what_prefix="«", what_suffix="»"
)

define narrator = Character(
    None,
    what_italic=True,
    what_color="#5a6072"
)


# ============================================================================
# VARIABLES DE SEGUIMIENTO
# ============================================================================

default aciertos = 0
default fallos = 0


# ============================================================================
# IMÁGENES ESPERADAS
# ----------------------------------------------------------------------------
# FONDOS:
#   bg_pasillo.png        → pasillo de instituto (apertura)
#   bg_aula.png           → aula de instituto vista desde la puerta
#   bg_pizarra.png        → frente del aula con la PROFESORA dibujada
#                           (aparece en la escena final, sin sprite aparte)
#
# PERSONAJES (PNG con fondo transparente):
#   sara.png              → Sara, expresión neutra (default)
#   sara_contenta.png     → Sara sonriendo (al acertar)
#   jonas.png             → Jonas, expresión neutra (default)
#   jonas_contento.png    → Jonas asintiendo / sonriendo (al acertar)
# ============================================================================

transform bg_fit:
    xanchor 0.5 yanchor 0.5
    xpos 0.5 ypos 0.5
    size (1920, 1080)

transform char_size:
    xanchor 0.5 yanchor 1.0
    ypos 1.0
    zoom 0.55

transform char_left:
    xanchor 0.5 yanchor 1.0
    xpos 0.25 ypos 1.0
    zoom 0.68

transform char_right:
    xanchor 0.5 yanchor 1.0
    xpos 0.75 ypos 1.0
    zoom 0.68

image bg aula = At("images/bg_aula.png", bg_fit)
image bg pasillo = At("images/bg_pasillo.png", bg_fit)
image bg pizarra = At("images/bg_pizarra.png", bg_fit)
image sara neutral = "images/sara.png"
image sara contenta = "images/sara_contenta.png"
image jonas neutral = "images/jonas.png"
image jonas contento = "images/jonas_contento.png"


# ============================================================================
# COMIENZO DE LA HISTORIA
# ============================================================================

label start:

    scene bg pasillo with fade

    narrator "Lunes, 8:25 de la mañana. Hartvig Nissens skole, Oslo."

    narrator "Tu primer día como estudiante de intercambio."

    narrator "Has llegado pronto. El edificio huele a madera y café. El pasillo está vacío, pero escuchas murmuros de un noruego que todavía no entiendes."

    narrator "Encuentras tu aula. Empujas la puerta."

    scene bg aula with fade

    narrator "Hay estudiantes ya dentro. Algunos te miran. Otros no."

    narrator "Te quedas un momento junto a la puerta. Tu cerebro busca el saludo correcto."

    # ----------------------------------------------------------------
    # DECISIÓN 1 — primer saludo al entrar
    # ----------------------------------------------------------------

    menu:
        "Decides decir..."

        "«Hei!»":
            mc "Hei!"
            narrator "Varias cabezas se vuelven hacia ti y te devuelven un «hei» perezoso. Otros siguen a lo suyo."
            narrator "Nadie reacciona como si hubieras dicho algo raro. Eso es buena señal."
            $ aciertos += 1
            narrator "Bien hecho. {i}Hei{/i} es el saludo todoterreno, funciona a cualquier hora y con cualquier persona en un contexto informal como el instituto."

        "«God morgen.»":
            mc "God morgen."
            narrator "Un par de cabezas se vuelven y te miran extrañados."
            narrator "No es un error grave, pero suena un poco a profesor."
            $ fallos += 1
            narrator "No incorrecto, pero entre adolescentes a las 8:30, un {i}hei{/i} habría sido más natural. {i}God morgen{/i} es perfectamente válido, solo que aquí suena más formal de lo necesario."

        "«Hallo?»":
            mc "Hallo?"
            narrator "Se escuchan algunos murmuros y risas de fondo, y los compañeros te observan con incredulidad"
            $ fallos += 1
            narrator "{i}Hallo{/i} en Noruega se usa casi exclusivamente al contestar el teléfono. Para entrar a clase, mejor {i}hei{/i}."

    narrator "Eliges un sitio libre y dejas la mochila. Una chica con pelo rubio te observa desde el pupitre de al lado y se dirige hacia ti."

    show sara neutral at char_right with moveinright

    sara "Hei. Du er den nye?"

    narrator "({i}«Hei. ¿Eres el/la nuevo/a?»{/i})"

    mc "Eh... sí. Hei."

    sara "Jeg heter Sara."

    narrator "Te tiende la mano. Te das cuenta de que en Noruega la gente da menos la mano de lo que pensabas, así que el gesto significa algo."

    # ----------------------------------------------------------------
    # DECISIÓN 2 — responder al nombre
    # ----------------------------------------------------------------

    menu:
        "Le respondes..."

        "«Hyggelig å møte deg. Jeg heter Alex.»":
            mc "Hyggelig å møte deg. Jeg heter... Alex."
            show sara contenta at char_right
            narrator "Sara sonríe. La fórmula completa, en orden, con la entonación más o menos en su sitio."
            sara "Ah, hyggelig! Du snakker norsk?"
            narrator "({i}«¡Encantada! ¿Hablas noruego?»{/i})"
            $ aciertos += 1
            narrator "Perfecto. {i}Hyggelig å møte deg{/i} es la fórmula ritual al conocer a alguien, y devolver el {i}jeg heter{/i} encaja como un guante."

        "«Jeg er Alex.»":
            mc "Jeg er Alex."
            show sara neutral at char_right
            sara "Aha. Hyggelig!"
            narrator "Sara no parece molesta, pero te falta una frase a medio camino."
            $ fallos += 1
            narrator "{i}Jeg er Alex{/i} es comprensible y se entiende, pero lo natural en este contexto es {i}jeg heter Alex{/i} («me llamo Alex»). {i}Jeg er{/i} se usa más para describir un estado (cansado, español, etc.)."

        "«Hi, I'm Alex.»":
            mc "Hi, I'm Alex."
            show sara neutral at char_right
            sara "Oh, you can speak English with me, no problem. But I thought you came here to learn norsk?"
            narrator "Sara sonríe, pero ha cambiado al inglés y probablemente lo mantenga toda la conversación."
            $ fallos += 1
            narrator "Casi todos los noruegos hablan inglés perfectamente y, si te ven dudar, se cambiarán al inglés. Eso es cómodo, pero {b}sabotea tu aprendizaje{/b}. Intenta resistir y seguir en noruego incluso si lo haces mal."

    # ----------------------------------------------------------------
    # DECISIÓN 3 — ¿de dónde eres?
    # ----------------------------------------------------------------

    sara "Hvor kommer du fra?"

    narrator "({i}«¿De dónde eres?»{/i})"

    menu:
        "Le contestas..."

        "«Jeg kommer fra Spania.»":
            mc "Jeg kommer fra Spania."
            show sara contenta at char_right
            sara "Spania! Jeg har vært i Barcelona. Veldig fint."
            narrator "({i}«¡España! He estado en Barcelona. Muy bonito.»{/i})"
            $ aciertos += 1
            narrator "Estructura limpia. {i}Jeg kommer fra + nombre del país{/i} es el patrón estándar. Y fíjate cómo {i}Spania{/i} ({i}/spánia/{/i}) se parece al inglés {i}Spain{/i}: ahí tienes otro cognado germánico."

        "«Spania.»":
            mc "Spania."
            show sara neutral at char_right
            sara "Ah, ok. Kult."
            narrator "Sara asiente, pero la respuesta a una frase con verbo era una frase con verbo, no una palabra suelta."
            $ fallos += 1
            narrator "Te entiende, claro, pero pierdes la oportunidad de practicar la frase entera. La fórmula {i}jeg kommer fra Spania{/i} la vas a usar en cada conversación nueva: cuanto antes la fijes, mejor."

        "«From Spain.»":
            mc "From Spain."
            show sara neutral at char_right
            sara "Spain, nice! Have you been to Norway before?"
            narrator "Y de nuevo, Sara cambia al inglés."
            $ fallos += 1
            narrator "Cada vez que respondes en inglés a una pregunta en noruego, le das permiso al noruego para cambiar de idioma. Resiste el impulso aunque la frase no sea perfecta."

    # ----------------------------------------------------------------
    # ENTRA JONAS
    # ----------------------------------------------------------------

    show sara neutral at char_left with move
    show jonas neutral at char_right with moveinright

    narrator "En ese momento, un chico alto con una sudadera saluda a Sara con la barbilla y se dirige hacia ti."

    jonas "Hei. Du er ny?"

    narrator "({i}«Hei. ¿Eres nuevo/a?»{/i})"

    mc "Sí... eh, ja."

    jonas "Jeg heter Jonas. Hvor gammel er du?"

    narrator "({i}«Me llamo Jonas. ¿Cuántos años tienes?»{/i})"

    # ----------------------------------------------------------------
    # DECISIÓN 4 — la edad
    # ----------------------------------------------------------------

    menu:
        "Le contestas que tienes diecisiete años:"

        "«Jeg er sytten år gammel.»":
            mc "Jeg er sytten år gammel."
            show jonas contento at char_right
            jonas "Aha, samme her. Vi er i samme klasse, da."
            narrator "({i}«Ah, igual que yo. Estamos en la misma clase, entonces.»{/i})"
            $ aciertos += 1
            narrator "Fórmula completa, perfecta para A1. Date cuenta de lo cerca que está del inglés: {i}I am seventeen years old{/i} → {i}Jeg er sytten år gammel{/i}. Palabra por palabra."

        "«Jeg er sytten.»":
            mc "Jeg er sytten."
            show jonas contento at char_right
            jonas "Sytten? Kult, jeg også."
            $ aciertos += 1
            narrator "También válido. En la práctica los noruegos suelen abreviar y decir solo el número. La versión completa ({i}sytten år gammel{/i}) es más útil cuando estás aprendiendo, pero {i}jeg er sytten{/i} suena igual de natural."

        "«Sytten.»":
            mc "Sytten."
            show jonas neutral at char_right
            jonas "Sytten. Ok."
            narrator "Jonas asiente, pero hay un silencio incómodo de un segundo."
            $ fallos += 1
            narrator "Aquí pasa lo mismo que antes: una palabra suelta como respuesta a una pregunta entera resulta un poco seca. Mete al menos un {i}jeg er{/i} delante."

    # ----------------------------------------------------------------
    # DECISIÓN 5 — final: despedida antes de que entre el profesor
    # ----------------------------------------------------------------

    narrator "Suena el timbre. La profesora entra al aula. Sara y Jonas tienen que sentarse. Sara te susurra antes:"

    sara "Vi snakkes etterpå, ok?"

    narrator "({i}«Hablamos después, ¿vale?»{/i})"

    menu:
        "Te despides con..."

        "«Ja, ha det!»":
            mc "Ja, ha det!"
            show sara neutral at char_left
            $ fallos += 1
            narrator "{i}Ha det{/i} es una despedida que se usa cuando alguien {b}se va{/b}. Pero aquí Sara no se va a ningún sitio. Encaja mejor un {i}okei{/i}, un {i}greit{/i} («vale») o, si quieres ser más expresivo/a, un {i}supert{/i} («genial»)."

        "«Greit!»":
            mc "Greit!"
            show sara contenta at char_left
            sara "{i}(sonríe sin girarse)\n{/i}"
            $ aciertos += 1
            narrator "{i}Greit{/i} significa «vale, ok» y es la respuesta natural a {i}vi snakkes etterpå{/i}. Has elegido bien."

        "«Vi sees!»":
            mc "Vi sees!"
            show sara contenta at char_left
            sara "{i}(asiente y mira al frente)\n{/i}"
            $ aciertos += 1
            narrator "{i}Vi sees{/i} («nos vemos») también funciona aquí. Es ligeramente más larga la transición, pero queda natural."

    hide sara
    hide jonas
    with dissolve

    scene bg pizarra with fade

    narrator "La profesora dice: {i}«God morgen, alle sammen. Velkommen tilbake.»{/i}"

    narrator "({i}«Buenos días a todos. Bienvenidos de vuelta.»{/i})"

    narrator "Aquí sí encaja el {i}god morgen{/i}: una profesora dirigiéndose a la clase entera, formal pero cálida. Mismo saludo, contexto distinto."

    narrator "Te recuestas en la silla. Ha durado dos minutos. Ya hay algo distinto."

    jump final


# ============================================================================
# FINAL — RESUMEN PERSONALIZADO
# ============================================================================

label final:

    scene black with fade

    narrator "{size=+10}Fin de la escena.{/size}"

    narrator "Has tomado 5 decisiones. Resultado: {b}[aciertos] respuestas naturales, [fallos] respuestas a mejorar{/b}."

    if aciertos >= 4:
        narrator "Excelente. Tienes interiorizado cuándo cada saludo encaja en su contexto. Estás listo/a para la siguiente actividad de la lección."
    elif aciertos >= 2:
        narrator "Vas bien. Has acertado lo esencial pero quedan matices por afinar. No pasa nada: vuelve a jugar la escena probando las opciones que descartaste y observa cómo cambia la reacción de Sara y Jonas."
    else:
        narrator "Esta vez has elegido respuestas demasiado breves o que sonaban formales en exceso. Te recomiendo volver a la lectura de la lección (especialmente la tabla de presentación) y rejugar la escena."

    narrator "Recuerda: en una visual novel puedes equivocarte sin consecuencias. {b}Eso es lo bueno de aprender aquí{/b}."

    narrator "Cierra esta ventana y vuelve a la lección para hacer la actividad de emparejamiento."

    return
