/**
 * scorm-api.js
 * Wrapper mínimo para la API SCORM 1.2.
 * Si encuentra la API del LMS (Moodle, Canvas...), reporta progreso y puntuación.
 * Si NO la encuentra (ejecución fuera de LMS, como en GitHub Pages),
 * funciona en modo "noop": registra en consola pero no falla.
 *
 * Curso: Velkommen til Norge!
 * Actividad: L1 - Empareja saludos con situaciones
 */

var SCORM = (function () {
  var api = null;
  var isInitialized = false;
  var isAvailable = false;

  // Buscar la API en la ventana actual y en las ventanas padre (hasta 7 niveles)
  function findAPI(win) {
    var attempts = 0;
    while (win && !win.API && win.parent && win.parent !== win && attempts < 7) {
      attempts++;
      win = win.parent;
    }
    return win && win.API ? win.API : null;
  }

  // Buscar API en window.opener si existe (ventanas emergentes desde LMS)
  function getAPI() {
    var theAPI = findAPI(window);
    if (theAPI === null && window.opener !== null && typeof window.opener !== "undefined") {
      theAPI = findAPI(window.opener);
    }
    return theAPI;
  }

  return {
    init: function () {
      api = getAPI();
      if (api === null) {
        console.info("[SCORM] No se ha detectado API de LMS. El SCO se ejecuta en modo independiente.");
        isAvailable = false;
        return false;
      }
      var result = api.LMSInitialize("");
      if (result === "true" || result === true) {
        isInitialized = true;
        isAvailable = true;
        console.info("[SCORM] LMSInitialize OK — conectado al LMS.");
        // Marcar como incompleto al empezar
        api.LMSSetValue("cmi.core.lesson_status", "incomplete");
        api.LMSCommit("");
        return true;
      } else {
        console.warn("[SCORM] LMSInitialize falló:", api.LMSGetLastError());
        return false;
      }
    },

    setScore: function (score) {
      if (!isAvailable || !isInitialized) {
        console.info("[SCORM] (noop) setScore:", score);
        return;
      }
      api.LMSSetValue("cmi.core.score.raw", String(score));
      api.LMSSetValue("cmi.core.score.min", "0");
      api.LMSSetValue("cmi.core.score.max", "100");
      api.LMSCommit("");
    },

    setStatus: function (status) {
      // status: "passed" | "failed" | "completed" | "incomplete"
      if (!isAvailable || !isInitialized) {
        console.info("[SCORM] (noop) setStatus:", status);
        return;
      }
      api.LMSSetValue("cmi.core.lesson_status", status);
      api.LMSCommit("");
    },

    finish: function () {
      if (!isAvailable || !isInitialized) {
        console.info("[SCORM] (noop) finish");
        return;
      }
      api.LMSCommit("");
      api.LMSFinish("");
      isInitialized = false;
    },

    isAvailable: function () {
      return isAvailable;
    }
  };
})();

// Auto-init al cargar la página
window.addEventListener("load", function () {
  SCORM.init();
});

// Cleanup al cerrar la ventana
window.addEventListener("beforeunload", function () {
  SCORM.finish();
});
