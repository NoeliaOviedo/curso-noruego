/**
 * activity.js
 * Lógica del emparejamiento de saludos noruegos con situaciones.
 * - Soporta drag-and-drop (HTML5)
 * - Soporta click-to-select para móviles y accesibilidad
 * - Feedback inmediato por cada intento
 * - Reporte SCORM al final
 */

// ============================================================
// Datos de la actividad
// ============================================================

const PAIRS = [
  {
    id: "p1",
    greeting: "God morgen",
    translation: "Buenos días",
    timeTag: "Mañana · formal",
    situation: "Son las 9:00 de la mañana. Entras a una panadería en Oslo y la dependienta te mira esperando que digas algo.",
    explanation: "👉 <em>God morgen</em> encaja por la hora (mañana temprano) y porque en una interacción de comercio con alguien que no conoces, este saludo queda natural sin sonar rebuscado."
  },
  {
    id: "p2",
    greeting: "Hei",
    translation: "Hola",
    timeTag: "Cualquier momento · informal",
    situation: "Te cruzas con un compañero del instituto por el pasillo. Es martes a las 11:30.",
    explanation: "👉 <em>Hei</em> es el saludo universal en Noruega. Entre compañeros, a cualquier hora del día, es siempre la elección correcta. Un <em>god dag</em> aquí sonaría raro y formal."
  },
  {
    id: "p3",
    greeting: "God kveld",
    translation: "Buenas noches (al saludar)",
    timeTag: "Tarde-noche · formal",
    situation: "Son las 21:00. Entras a un restaurante en Bergen y el camarero se acerca a recibirte.",
    explanation: "👉 <em>God kveld</em> es el saludo nocturno por excelencia: encaja por la hora y por el contexto (entrar a un sitio donde te van a atender). No confundas con <em>god natt</em>, que se usa solo al despedirse antes de dormir."
  },
  {
    id: "p4",
    greeting: "Hallo",
    translation: "Hola (más formal que Hei)",
    timeTag: "Teléfono",
    situation: "Suena tu móvil. Es un número desconocido y lo descuelgas.",
    explanation: "👉 <em>Hallo</em> es lo que dicen los noruegos al contestar el teléfono, igual que el inglés <em>hello</em>. Suena más formal que <em>hei</em>, pero en el teléfono es la convención."
  },
  {
    id: "p5",
    greeting: "Ha det bra",
    translation: "Adiós, cuídate",
    timeTag: "Despedida",
    situation: "Sales de una cafetería después de pagar. Quieres despedirte del camarero con amabilidad.",
    explanation: "👉 <em>Ha det bra</em> (o solo <em>ha det</em>) es la despedida más común. Literalmente significa «que lo tengas bien». Sirve para amigos y para desconocidos por igual."
  },
  {
    id: "p6",
    greeting: "Hyggelig å møte deg",
    translation: "Encantado/a de conocerte",
    timeTag: "Primer encuentro",
    situation: "Tu profesora del intercambio te presenta a otro estudiante noruego. Le estrechas la mano.",
    explanation: "👉 <em>Hyggelig å møte deg</em> es la frase ritual al conocer a alguien por primera vez. <em>Hyggelig</em> es una palabra muy noruega: significa «agradable, acogedor», la misma raíz que <em>koselig</em>."
  }
];

const PASS_THRESHOLD = 70; // % de aciertos en el primer intento para considerar "passed"

// ============================================================
// Estado de la actividad
// ============================================================

const state = {
  matched: 0,
  attempts: 0,      // intentos totales (aciertos + fallos)
  correct: 0,       // aciertos
  selectedGreetingId: null,
  finished: false
};

// ============================================================
// Helpers de render
// ============================================================

function shuffleArray(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function renderActivity() {
  const greetingsList = document.getElementById("greetingsList");
  const situationsList = document.getElementById("situationsList");

  greetingsList.innerHTML = "";
  situationsList.innerHTML = "";

  const shuffledGreetings = shuffleArray(PAIRS);
  const shuffledSituations = shuffleArray(PAIRS);

  shuffledGreetings.forEach(pair => {
    const li = document.createElement("li");
    li.className = "greeting-card";
    li.draggable = true;
    li.dataset.pairId = pair.id;
    li.setAttribute("role", "button");
    li.setAttribute("tabindex", "0");
    li.setAttribute("aria-label", `Saludo: ${pair.greeting}. ${pair.translation}`);
    li.innerHTML = `${pair.greeting}<span class="greeting-translation">${pair.translation}</span>`;
    greetingsList.appendChild(li);
  });

  shuffledSituations.forEach(pair => {
    const li = document.createElement("li");
    li.className = "situation-card";
    li.dataset.pairId = pair.id;
    li.setAttribute("role", "button");
    li.setAttribute("tabindex", "0");
    li.setAttribute("aria-label", `Situación: ${pair.situation}`);
    li.innerHTML = `<div><span class="situation-time">${pair.timeTag}</span>${pair.situation}</div>`;
    situationsList.appendChild(li);
  });

  attachEventListeners();
}

// ============================================================
// Event listeners
// ============================================================

function attachEventListeners() {
  document.querySelectorAll(".greeting-card").forEach(card => {
    card.addEventListener("dragstart", handleDragStart);
    card.addEventListener("dragend", handleDragEnd);
    card.addEventListener("click", handleGreetingClick);
    card.addEventListener("keydown", handleKeyboard);
  });

  document.querySelectorAll(".situation-card").forEach(card => {
    card.addEventListener("dragover", handleDragOver);
    card.addEventListener("dragleave", handleDragLeave);
    card.addEventListener("drop", handleDrop);
    card.addEventListener("click", handleSituationClick);
    card.addEventListener("keydown", handleKeyboard);
  });

  document.getElementById("restartBtn").addEventListener("click", restartActivity);
}

// ===== Drag and drop =====

function handleDragStart(e) {
  if (e.currentTarget.classList.contains("matched")) {
    e.preventDefault();
    return;
  }
  e.currentTarget.classList.add("dragging");
  e.dataTransfer.setData("text/plain", e.currentTarget.dataset.pairId);
  e.dataTransfer.effectAllowed = "move";
}

function handleDragEnd(e) {
  e.currentTarget.classList.remove("dragging");
}

function handleDragOver(e) {
  if (e.currentTarget.classList.contains("matched")) return;
  e.preventDefault();
  e.dataTransfer.dropEffect = "move";
  e.currentTarget.classList.add("drag-over");
}

function handleDragLeave(e) {
  e.currentTarget.classList.remove("drag-over");
}

function handleDrop(e) {
  e.preventDefault();
  e.currentTarget.classList.remove("drag-over");
  if (e.currentTarget.classList.contains("matched")) return;

  const greetingPairId = e.dataTransfer.getData("text/plain");
  const situationPairId = e.currentTarget.dataset.pairId;
  checkMatch(greetingPairId, situationPairId);
}

// ===== Click-to-select (móvil + accesibilidad) =====

function handleGreetingClick(e) {
  const card = e.currentTarget;
  if (card.classList.contains("matched")) return;

  // Deseleccionar otros
  document.querySelectorAll(".greeting-card.selected").forEach(c => {
    if (c !== card) c.classList.remove("selected");
  });

  if (state.selectedGreetingId === card.dataset.pairId) {
    card.classList.remove("selected");
    state.selectedGreetingId = null;
  } else {
    card.classList.add("selected");
    state.selectedGreetingId = card.dataset.pairId;
  }
}

function handleSituationClick(e) {
  const card = e.currentTarget;
  if (card.classList.contains("matched")) return;
  if (!state.selectedGreetingId) {
    showLiveFeedback("Primero selecciona un saludo de la columna izquierda.", "info");
    return;
  }
  checkMatch(state.selectedGreetingId, card.dataset.pairId);
  state.selectedGreetingId = null;
  document.querySelectorAll(".greeting-card.selected").forEach(c => c.classList.remove("selected"));
}

// ===== Teclado (accesibilidad) =====

function handleKeyboard(e) {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    e.currentTarget.click();
  }
}

// ============================================================
// Lógica de emparejamiento
// ============================================================

function checkMatch(greetingPairId, situationPairId) {
  state.attempts++;
  const isCorrect = greetingPairId === situationPairId;
  const pair = PAIRS.find(p => p.id === greetingPairId);

  if (isCorrect) {
    state.correct++;
    state.matched++;
    markAsMatched(greetingPairId, situationPairId);
    showLiveFeedback(`✓ ¡Correcto! ${stripHtml(pair.explanation)}`, "success");
    updateProgress();

    if (state.matched === PAIRS.length) {
      setTimeout(finishActivity, 1200);
    }
  } else {
    const situationCard = document.querySelector(`.situation-card[data-pair-id="${situationPairId}"]`);
    situationCard.classList.add("error-flash");
    setTimeout(() => situationCard.classList.remove("error-flash"), 600);
    showLiveFeedback(`✗ No es exactamente ahí. Piensa en la hora y en el contexto.`, "error");
  }
}

function markAsMatched(greetingPairId, situationPairId) {
  const greetingCard = document.querySelector(`.greeting-card[data-pair-id="${greetingPairId}"]`);
  const situationCard = document.querySelector(`.situation-card[data-pair-id="${situationPairId}"]`);
  greetingCard.classList.add("matched");
  greetingCard.classList.remove("selected");
  greetingCard.draggable = false;
  situationCard.classList.add("matched");
}

function updateProgress() {
  const percent = (state.matched / PAIRS.length) * 100;
  const scorePercent = state.attempts > 0
    ? Math.round((state.correct / state.attempts) * 100)
    : 0;
  document.getElementById("progressFill").style.width = `${percent}%`;
  document.getElementById("progressCount").textContent = state.matched;
  document.getElementById("scoreCount").textContent = scorePercent;
}

// ============================================================
// Feedback en vivo
// ============================================================

function showLiveFeedback(message, type) {
  const el = document.getElementById("liveFeedback");
  el.className = `live-feedback show ${type}`;
  el.innerHTML = message;
  clearTimeout(el._timeout);
  el._timeout = setTimeout(() => {
    el.classList.remove("show");
  }, 3500);
}

function stripHtml(html) {
  const div = document.createElement("div");
  div.innerHTML = html;
  return div.textContent || div.innerText || "";
}

// ============================================================
// Finalización + reporte SCORM
// ============================================================

function finishActivity() {
  if (state.finished) return;
  state.finished = true;

  const scorePercent = Math.round((state.correct / state.attempts) * 100);
  const passed = scorePercent >= PASS_THRESHOLD;

  // Reportar al LMS
  SCORM.setScore(scorePercent);
  SCORM.setStatus(passed ? "passed" : "completed");

  // Mostrar feedback final
  const finalEl = document.getElementById("finalFeedback");
  const titleEl = document.getElementById("finalTitle");
  const msgEl = document.getElementById("finalMessage");

  if (passed) {
    titleEl.textContent = "🎉 ¡Bra jobbet! (¡Buen trabajo!)";
    msgEl.innerHTML = `
      Has acertado <strong>${state.correct} de ${state.attempts}</strong> intentos.
      Puntuación: <strong>${scorePercent} / 100</strong>.
      <br><br>
      Ya tienes interiorizado cuándo usar cada saludo según el contexto y la hora.
      Puedes volver a la lección y pasar a la siguiente actividad.
    `;
  } else {
    titleEl.textContent = "✓ Actividad completada";
    msgEl.innerHTML = `
      Has acertado <strong>${state.correct} de ${state.attempts}</strong> intentos.
      Puntuación: <strong>${scorePercent} / 100</strong>.
      <br><br>
      Has terminado la actividad, pero te recomendamos repetirla para fijar mejor
      cuándo usar cada saludo. Vuelve a la lectura de la lección si necesitas repasar.
    `;
  }

  finalEl.classList.remove("hidden");
  finalEl.scrollIntoView({ behavior: "smooth", block: "center" });
}

// ============================================================
// Reinicio
// ============================================================

function restartActivity() {
  state.matched = 0;
  state.attempts = 0;
  state.correct = 0;
  state.selectedGreetingId = null;
  state.finished = false;

  document.getElementById("finalFeedback").classList.add("hidden");
  document.getElementById("progressFill").style.width = "0%";
  document.getElementById("progressCount").textContent = "0";
  document.getElementById("scoreCount").textContent = "0";

  renderActivity();
}

// ============================================================
// Init
// ============================================================

document.addEventListener("DOMContentLoaded", renderActivity);
