# Cuestionario QTI 1.2 — L2 Números noruegos

**Velkommen til Norge! · Curso de noruego bokmål A0 → A1**
Cuestionario de 10 preguntas sobre números (0-100), días de la semana, meses y festividades del calendario noruego.

---

## Contenido del paquete

- `imsmanifest.xml` — manifest IMS Content Package
- `quiz_numeros.xml` — cuestionario en formato QTI 1.2
- `README.md` — este archivo

## Estructura de las preguntas

| # | Tipo | Tema |
|---|------|------|
| 1 | Opción múltiple | Reconocer el número 27 (*tjuesju*) |
| 2 | Opción múltiple | Identificar el día dedicado a Thor |
| 3 | Opción múltiple | Fecha del día nacional noruego |
| 4 | Opción múltiple | Identificar cognado germánico |
| 5 | Rellena el hueco | Escribir 14 en noruego |
| 6 | Rellena el hueco | Escribir 41 en noruego moderno |
| 7 | Rellena el hueco | Mes en una frase |
| 8 | Asociación | Días con dioses mitológicos |
| 9 | Asociación | Cifras con palabras |
| 10 | Asociación | Festividades con descripción |

Cada pregunta puntúa 1 punto. Total: 10 puntos. Nota mínima recomendada para considerar superado: 7/10.

## Cómo importar el cuestionario

### En Moodle

1. Entra a tu curso → **Configuración → Banco de preguntas → Importar**.
2. Formato: **IMS QTI 1.2**.
3. Sube el archivo `quiz_numeros.xml` (NO el ZIP entero — Moodle solo necesita el XML del cuestionario).
4. Elige la categoría destino y pulsa **Importar**.
5. Una vez importadas, crea un cuestionario nuevo y añade las preguntas desde el banco.

### En Canvas

1. Entra a tu curso → **Configuración → Importar contenido del curso**.
2. Tipo de contenido: **QTI .zip file**.
3. Sube el ZIP completo del paquete.
4. Pulsa **Importar**.

### En Blackboard

1. Panel de control del curso → **Tests, Surveys, and Pools → Pools**.
2. **Import Pool** → **Browse** → sube el ZIP.
3. Las preguntas aparecerán en el banco de preguntas listas para usar.

### Visor online (sin LMS)

Si solo quieres ver el cuestionario sin importarlo a un LMS:

- [QTIWorks Player](https://qtiworks.ucles.org.uk/) — visor oficial QTI online (mejor compatibilidad con QTI 2.1; para QTI 1.2 puede mostrar warnings cosméticos).
- Calibre + plugin QTI Viewer si trabajas en local.

## Sobre el formato QTI

**QTI 1.2 (Question and Test Interoperability)** es un estándar de IMS Global Learning Consortium diseñado para que las preguntas y cuestionarios sean **interoperables entre plataformas educativas**. Permite mover un mismo cuestionario entre Moodle, Canvas, Blackboard y otros LMS sin reescribirlo. Se utiliza desde 2002 y sigue siendo el formato más universalmente soportado por LMS en producción.

Este cuestionario usa QTI 1.2 (no 2.1 ni 3.0) porque es el que Moodle importa de forma nativa sin plugins adicionales.

## Limitaciones

- El cuestionario QTI no se ejecuta directamente desde GitHub Pages, donde se aloja el curso. El estándar QTI requiere un motor de evaluación (parte del LMS) que GitHub Pages no proporciona.
- Si no tienes acceso a un LMS, hay una **versión imprimible con la clave de respuestas** en el archivo `quiz-numeros-clave.pdf`, en la misma carpeta de la L2.

## Licencia

Creative Commons BY-NC-SA 4.0
Autora: Noelia Oviedo Marín
Máster en Letras Digitales — Producción de Materiales Educativos Digitales
Curso 2025-2026
